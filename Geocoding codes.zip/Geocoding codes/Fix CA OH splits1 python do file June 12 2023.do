//Screwed up maximum number of rows in the python file (499,500, which is higher than some of my initial csv's for OH and CA)

//Ohio

clear
use "/GRF1940_master/component files/Testsmallfiles/GRF_OH_split.dta"
tab svar
clear
import delimited "/GRF1940_master/component files/Testsmallfiles/geocoded_OH_split_1.csv"
rename v1 histid
drop if histid=="histid"
merge 1:1 histid using "/GRF1940_master/component files/Testsmallfiles/GRF_OH_split.dta", generate(_merge_geocoded)
tab svar if _merge_geocoded==2
tab svar if _merge_geocoded==3
tab svar

//Find the right addresses
keep histid s_oc_fulladdress svar _merge_geocoded
drop if svar==2
drop if _merge_geocoded==3

drop svar _merge_geocoded

//as expected, they're all from Youngstown, OH

//Export
export delimited histid s_oc_fulladdress using "/GRF1940_master/component files/Testsmallfiles/GRF_OH_split_fix.csv", nolabel datafmt



//CA
clear
use "/GRF1940_master/component files/Testsmallfiles/GRF_CA_split.dta"
clear
import delimited "/GRF1940_master/component files/Testsmallfiles/geocoded_CA_split_1.csv"
rename v1 histid
drop if histid=="histid"
merge 1:1 histid using "/GRF1940_master/component files/Testsmallfiles/GRF_CA_split.dta", generate(_merge_geocoded)
tab svar if _merge_geocoded==2
tab svar if _merge_geocoded==3
tab svar

//Find the right addresses
keep histid s_oc_fulladdress svar _merge_geocoded
drop if svar==2
drop if _merge_geocoded==3

drop svar _merge_geocoded

//as expected, they're all from San Jose, CA

//Export
export delimited histid s_oc_fulladdress using "/GRF1940_master/component files/Testsmallfiles/GRF_CA_split_fix.csv", nolabel datafmt




//Double check IL. NY and PA were split evenly and combined on separate runs with other files, so should be fine
clear
use "/GRF1940_master/component files/Testsmallfiles/GRF_IL_split.dta"
clear
import delimited "/GRF1940_master/component files/Testsmallfiles/geocoded_IL_split_1.csv"
rename v1 histid
drop if histid=="histid"
merge 1:1 histid using "/GRF1940_master/component files/Testsmallfiles/GRF_IL_split.dta", generate(_merge_geocoded)
tab svar if _merge_geocoded==2
tab svar if _merge_geocoded==3
tab svar

//looks good
clear

