clear

local citystatefiles AkronOH AlbanyNY AllentownPA AltoonaPA AtlantaGA AtlanticCityNJ AuburnNY AugustaGA AuroraIL AustinTX BaltimoreMD BayCityMI BayonneNJ BerkeleyCA BinghamtonNY BirminghamAL BostonMA BridgeportCT BrocktonMA BronxNY BrooklynNY BuffaloNY ButteMT CambridgeMA CamdenNJ CantonOH CharlestonSC CharlestonWV CharlotteNC ChattanoogaTN ChelseaMA ChesterPA ChicagoIL CiceroIL CincinnatiOH ClevelandOH ColumbusOH CovingtonKY DallasTX DavenportIA DaytonOH DenverCO DesMoinesIA DetroitMI DubuqueIA DuluthMN EastOrangeNJ EastStLouisIL ElizabethNJ ElmiraNY ElPasoTX EriePA EvanstonIL EvansvilleIN FallRiverMA FitchburgMA FlintMI FortWayneIN FortWorthTX GalvestonTX GaryIN GlendaleCA GrandRapidsMI HammondIN HarrisburgPA HartfordCT HaverhillMA HobokenNJ HolyokeMA HoustonTX HuntingtonWV IndianapolisIN JacksonvilleFL JerseyCityNJ JohnstownPA JolietIL JoplinMO KansasCityKS KansasCityMO KnoxvilleTN LaCrosseWI LakewoodOH LancasterPA LansingMI LawrenceMA LincolnNE LittleRockAR LongBeachCA LosAngelesCA LouisvilleKY LowellMA LynnMA MadisonWI MaldenMA ManchesterNH ManhattanNY McKeesportPA MemphisTN MeridenCT MiamiFL MilwaukeeWI MinneapolisMN MobileAL MontgomeryAL MountVernonNY NashvilleTN NewarkNJ NewBedfordMA NewBritainCT NewCastlePA NewHavenCT NewOrleansLA NewportKY NewtonMA NiagaraFallsNY NorfolkVA OaklandCA OakParkIL OklahomaCityOK OmahaNE OshkoshWI PasadenaCA PassaicNJ PatersonNJ PawtucketRI PeoriaIL PhiladelphiaPA PhoenixAZ PittsburghPA PontiacMI PortlandME PortlandOR PoughkeepsieNY ProvidenceRI PuebloCO QueensNY QuincyIL QuincyMA RacineWI ReadingPA RichmondVA RochesterNY RockfordIL SacramentoCA SaginawMI SalemMA SaltLakeCityUT SanAntonioTX SanDiegoCA SanFranciscoCA SanJoseCA SavannahGA SchenectadyNY ScrantonPA SeattleWA ShreveportLA SiouxCityIA SomervilleMA SouthBendIN SpokaneWA SpringfieldIL SpringfieldMA SpringfieldOH StatenIslandNY StJosephMO StLouisMO StPaulMN SuperiorWI SyracuseNY TacomaWA TampaFL TauntonMA TerreHauteIN ToledoOH TopekaKS TrentonNJ TroyNY TulsaOK UticaNY WashingtonDC WaterburyCT WichitaKS Wilkes-BarrePA WilliamsportPA WilmingtonDE Winston-SalemNC WoonsocketRI WorcesterMA YonkersNY YorkPA YoungstownOH

foreach n of local citystatefiles {
	use "/GRF1940_master/component files/`n'.dta"
gen s_state=substr(b_city,-2,2)
gen s_city=substr(b_city, 1, strlen(b_city) - 2)

gen s_cityname=s_city
replace s_cityname = regexs(1)+" "+regexs(2)+regexs(3) if(regexm(s_city, "([a-zA-Z]+)([A-Z]+)([a-z]+)"))

	save "/GRF1940_master/component files/`n'.dta", replace
	clear
}

//Some edge cases
use "/GRF1940_master/component files/EastStLouisIL.dta"
replace s_cityname="East St Louis" if s_cityname=="EastSt Louis"
save "/GRF1940_master/component files/EastStLouisIL.dta", replace
use "/GRF1940_master/component files/McKeesportPA.dta"
replace s_cityname="McKeesport" if s_cityname=="Mc Keesport"
save "/GRF1940_master/component files/McKeesportPA.dta", replace
use "/GRF1940_master/component files/SaltLakeCityUT.dta"
replace s_cityname="Salt Lake City" if s_cityname=="SaltLake City"
save "/GRF1940_master/component files/SaltLakeCityUT.dta", replace

