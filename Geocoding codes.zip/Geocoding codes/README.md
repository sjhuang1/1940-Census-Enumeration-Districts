These are stata do files and python scripts for the geocoding process. 
Requires the GRF data from the UTP. 
Requires an OpenCage geocoding plan (to use with the python scripts): https://opencagedata.com

Start with the Stata do files in the following order:
1. "Tostring GRF1940_b_ed May 27 2023.do"
2. "Prepping GRF1940master file May 27 2023.do"
3. "Creating readable citynames GRF1940 May 30 2023.do"
4. "Creating QGIS readable address May 30 2023.do" 
These create a series of datasets for each city/state combo.

Then use:
5. "API call list 1940GRFmaster May 30 2023.do"
which also includes general instructions. This creates a master file with no duplicated addresses (using the first histid that appears) and splits it into CSV batches that are readable by the OpenCage API (while preserving that histid). These correspond to python files in the next section

Finally, use:
6. "Fix CA OH splits1 python do file June 12 2023.do"
which fixes an error in how the data was split in the previous do file for California and Ohio.

Next, create an environment, and install the following packages (with their dependencies): opencage asyncio aiohttp backoff tqdm

Run the python scripts included here. Scripts are based off documentation and examples from the OpenCage API: https://opencagedata.com/api . Each script is meant for a single day under a plan with 500k API calls. API key is blanked out in each script: insert your API key between the single quotes.

This is likely not the most parsimonious method. Do files and Python scripts are provided as is. Feel free (as with everything else under the license) to adapt to a different geocoder or statistical software as needed.